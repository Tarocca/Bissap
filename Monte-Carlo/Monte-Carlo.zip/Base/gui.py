# -*- coding: utf-8 -*-
"""
Created on Thu Jul 27 17:30:43 2017

@author: Stephane Guinard
"""

###############################################################
#                                                             #
#       Seulement pour ceux qui ont fini le reste !!          #
#                                                             #
###############################################################

from __future__ import division
import matplotlib.pyplot as plt # matplotlib
import numpy as np
import tirage_points
import distance_cercle

def show_points(points):
    pass

# Tests unitaires    
if __name__ == "__main__":
    # Obtenir une liste de points
    #points = tirage_points.find_points(5000)
    # Afficher les points
    #show_points(points)

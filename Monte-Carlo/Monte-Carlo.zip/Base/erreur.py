# -*- coding: utf-8 -*-
"""
Created on Tue Oct 24 12:04:35 2017

@author: sguinard
"""

import tirage_points
import distance_cercle
import math

def create_distrib(points):
    """
        Fonction qui permet de créer une distribution 
        à partir d'un tirage aléatoire de points
        en fonction de leur appartenance ou non 
        au quart de cercle trigonométrique
    
        :param points: ensemble de points tirés aléatoirement
        :type points: liste(tuple(float,float),...)
        :return: distribution des points
        :rtype: liste(int)
    """
    pass
    
def moyenne(distrib):
    """
        Fonction qui calcule la moyenne d'une distribution
    
        :param distrib: distribution de points
        :type distrib: liste(int)
        :return: moyenne de la distribution
        :rtype: float
    """
    pass

def variance(distrib):
    """
        Fonction qui calcule la variance d'une distribution
        
        :param distrib: distribution de points
        :type distrib: liste(float)
        :return: variance de la distribution
        :rtype: float
    """
    pass
    
if __name__ == "__main__":
    

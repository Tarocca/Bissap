# -*- coding: utf-8 -*-

#-- QUESTION 8 --#
def jouer(solution, nb_coup):
    """
        Fonction comprenant la boucle de jeu du mastermind.
    
        :param solution: combinaison a deviner
        :type solution: list(int, ...)
        :param nb_coup: nombre de coup pour deviner la combinaison
        :type nb_coup: int
        :return: resultat de la partie
        :rtype: bool
    """
    
    pass

def sol_aleatoire(taille_combinaison):
    """
        Fonction permettant de générer une combinaison
        aléatoire
    
        :param taille_combinaison: taille de la combinaison a générer
        :type taille_combinaison: int
        :return: combinaison
        :rtype: list(int, int, ... )
    """
    
    pass




# Tests
if __name__ == "__main__":
        
    #-- QUESTION 8 --#
    print('\nQuestion 8')
    solution = [2,0,3,1]
    nb_coup = 5
    resultat = jouer(solution, nb_coup)
    if resultat:
        print('Gagné !')
    else:
        print('Perdu !')
    #-- QUESTION 9 --#
    '''
    print('\nQuestion 9')
    taille_combinaison = 5
    solution = sol_aleatoire(taille_combinaison)
    nb_coup = 5
    resultat = jouer(solution, nb_coup)
    if resultat:
        print('Gagné !')
    else:
        couleurs_codes = {0: "R" , 1: "B" , 2: "J" , 3: "V" , 4: "N" , 5: "M" , 6: "F" , 7: "O" }
        print('Perdu ! La solution etait {}'.format([couleurs_codes[c] for c in solution]))
    '''
    
